build_tiny() {
   set -e
   ARCH=`uname -i`
   CoreMarkPath=$(cd `dirname $0`; pwd)
   myOBJPATH=/usr/bin
   if [ $ARCH = "aarch32" ]; then
       CFLAGS="-O2 -mcpu=cortex-a9" make
   elif [ $ARCH = "aarch64"  ]; then
       CFLAGS="-O2 -mcpu=cortex-a57" make
   else
       make
   fi

}

build_tiny

